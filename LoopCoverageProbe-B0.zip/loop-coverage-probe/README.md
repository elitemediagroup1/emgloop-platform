# Loop Coverage Probe (B0)

A local, read-only Windows probe that answers ONE question:

> Do the native Microsoft Teams and Telegram desktop apps on this machine raise
> **Windows notifications** that Microsoft's documented `UserNotificationListener`
> API can see?

It is a feasibility probe for stage B0 only. It is **not** connected to Loop, sends
nothing anywhere, and reads no message content.

## What it does, and does NOT do

Per notification it records EXACTLY four things:
1. the producing app's identity (AppUserModelId) — app-level, never a person;
2. the timestamp;
3. whether the toast had any text elements (a **count > 0**, never the text);
4. the classification Teams / Telegram (other apps are counted only, with no identity or time).

It does **not**: read notification titles/previews/sender/conversation/body; use UI
Automation or accessibility trees; automate, open or navigate Teams/Telegram; use
WebView2 or any DOM; make any network request; read cookies, tokens, credentials,
session state, or any Teams/Telegram local database; or send anything to Loop or any
external service. It has no send/reply/react/edit/delete capability of any kind, and it
never removes or modifies a notification.

## Requirements
- Windows 10 2004 (build 19041) or newer.
- .NET 10 SDK.
- Windows 10/11 SDK (for `makeappx.exe` / `signtool.exe`) — or Visual Studio 2022+.

## Build, package, install (command line)
Elevated PowerShell on Windows:
```powershell
./build.ps1                       # publish + pack MSIX + self-signed dev cert + sign
Add-AppxPackage ./LoopCoverageProbe.msix
```
(GUI alternative: open `LoopCoverageProbe.slnx` in Visual Studio, set `ProbePackaging`
as startup, pick a sideload cert, Deploy.)

## Run the test
1. Launch **Loop Coverage Probe (B0)**.
2. Click **Grant notification access** and approve the Windows prompt.
3. Click **Start coverage test**.
4. **Use Teams and Telegram normally** for a while (receive a few messages).
5. Watch the counters, then **Stop**.

Records are written to `%LOCALAPPDATA%\LoopCoverageProbe\coverage.jsonl`
(e.g. `{"kind":"Teams","appId":"MSTeams_8wekyb3d8bbwe!MSTeams","ts":"...","hadText":true}`).

## How to read the result
- **Teams lines present** → native Teams routes notifications to Windows; the listener path is viable for Teams.
- **Teams lines absent but "Other" > 0** → the listener works, but Teams is using its own in-app banners (the "Teams built-in" notification style), so this path can't see Teams. (Telegram is the same story via its "native notifications" setting.)
- **Everything zero** → notification access wasn't granted, or the app lacks package identity. Re-check the grant and that it was installed as the signed MSIX.

## Remove it completely
```powershell
./cleanup.ps1     # uninstalls the app, deletes coverage.jsonl, removes the dev cert
```
Then optionally revoke under **Settings → Privacy & security → Notifications**.

## Honesty note
`ProbeCore` (classification + record shape + serializer) and the safety test-suite
(`ProbeCore.Tests`, including the source-scan of `ProbeApp` and the manifest) were built
and RUN on Linux — results are real. The WinForms app (`ProbeApp`) and the MSIX packaging
target Windows and were **authored but not compiled or run** in that environment; build
them on Windows per above.
