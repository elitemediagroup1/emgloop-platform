using System.Reflection;
using System.Text.Json;
using Loop.CoverageProbe.Core;

int failures = 0;
void Check(bool cond, string name)
{
    Console.WriteLine((cond ? "  ok   " : "  FAIL ") + name);
    if (!cond) failures++;
}

// --- 1. Source classification is content-free and correct -----------------------------------
Check(SourceClassifier.Classify("MSTeams_8wekyb3d8bbwe!MSTeams") == AppKind.Teams, "new Teams AUMID -> Teams");
Check(SourceClassifier.Classify("com.squirrel.Teams.Teams") == AppKind.Teams, "classic Teams AUMID -> Teams");
Check(SourceClassifier.Classify("msteams_8WEKYB3D8BBWE!msteams") == AppKind.Teams, "Teams AUMID is case-insensitive");
Check(SourceClassifier.Classify("Telegram.TelegramDesktop") == AppKind.Telegram, "Telegram Win32 AUMID -> Telegram");
Check(SourceClassifier.Classify("TelegramMessengerLLP.TelegramDesktop_t2t7fp3z3f9tj!Telegram.TelegramDesktop") == AppKind.Telegram, "Telegram Store AUMID -> Telegram");
Check(SourceClassifier.Classify("com.whatsapp.desktop") == AppKind.Other, "unrelated app -> Other");
Check(SourceClassifier.Classify("") == AppKind.Other, "empty -> Other");
Check(SourceClassifier.Classify(null) == AppKind.Other, "null -> Other");
Check(SourceClassifier.Classify("   ") == AppKind.Other, "whitespace -> Other");

// --- 2. The record shape cannot carry notification content ----------------------------------
var props = typeof(ProbeRecord).GetProperties(BindingFlags.Public | BindingFlags.Instance)
    .Select(p => p.Name).OrderBy(n => n).ToArray();
var expected = new[] { "AppIdentity", "HadTextElements", "Kind", "TimestampUtc" };
Check(props.SequenceEqual(expected), "ProbeRecord has EXACTLY the four allowed properties");
string[] forbiddenNames = { "Title", "Body", "Text", "Preview", "Sender", "Content", "Message", "Conversation", "Name", "Subject" };
Check(!props.Any(p => forbiddenNames.Any(f => p.Contains(f, StringComparison.OrdinalIgnoreCase))
                      && p != "HadTextElements"), "no property name implies stored content");

// --- 3. Serialization emits only the four allowlisted keys ----------------------------------
var rec = new ProbeRecord(AppKind.Teams, "MSTeams_8wekyb3d8bbwe!MSTeams",
    DateTimeOffset.Parse("2026-09-19T18:25:10Z"), true);
var line = RecordSerializer.ToJsonLine(rec);
using (var doc = JsonDocument.Parse(line))
{
    var keys = doc.RootElement.EnumerateObject().Select(p => p.Name).OrderBy(k => k).ToArray();
    Check(keys.SequenceEqual(new[] { "appId", "hadText", "kind", "ts" }), "serialized line has exactly the allowlisted keys");
    Check(doc.RootElement.GetProperty("hadText").GetBoolean(), "hadText serialized as bool");
    Check(doc.RootElement.GetProperty("kind").GetString() == "Teams", "kind serialized");
}
Check(RecordSerializer.AllowedKeys.OrderBy(k => k).SequenceEqual(new[] { "appId", "hadText", "kind", "ts" }), "AllowedKeys pinned");
// A record that never had text serializes hadText=false and still leaks nothing.
var rec2 = new ProbeRecord(AppKind.Telegram, "Telegram.TelegramDesktop", DateTimeOffset.UtcNow, false);
Check(RecordSerializer.ToJsonLine(rec2).Contains("\"hadText\":false"), "hadText=false path");

// --- 4. The Windows app source contains no forbidden mechanism ------------------------------
string? probeRoot = FindProbeRoot(AppContext.BaseDirectory);
Check(probeRoot != null, "found the probe root for source scanning");
if (probeRoot != null)
{
    var appDir = Path.Combine(probeRoot, "ProbeApp");
    var manifest = Path.Combine(probeRoot, "Packaging", "Package.appxmanifest");
    var appSrc = string.Join("\n", Directory.GetFiles(appDir, "*.cs").Select(File.ReadAllText));
    // The forbidden-token scan is about the CODE, so strip comments first: a reassurance
    // comment like "touches no cookie" must not read as using cookies.
    var appCodeLower = StripCsComments(appSrc).ToLowerInvariant();

    string[] forbidden = {
        // networking of any kind
        "system.net", "httpclient", "webclient", "webrequest", "httpwebrequest",
        "tcpclient", "udpclient", "socket", "dns.", "namedpipe",
        // modifying notifications (write capability on the listener)
        "removenotification", "clearnotifications",
        // UI Automation / accessibility (explicitly out of scope for B0)
        "uiautomation", "automationelement", "system.windows.automation",
        // embedded browser / DOM
        "webview", "corewebview2",
        // OS hooks beyond scope
        "setwineventhook", "setwindowshookex",
        // capturing notification text content
        "adaptivenotificationtext", "gettextelements()[", "texts[",
        // credentials / session / provider local stores
        "cookie", "password", "credential", "indexeddb", "leveldb", "sqlite", "\\packages\\msteams",
    };
    foreach (var tok in forbidden)
        Check(!appCodeLower.Contains(tok), $"ProbeApp code contains no '{tok}'");

    // Positive guarantees: it DOES use the documented consent API and marks the count-only site.
    Check(appSrc.Contains("RequestAccessAsync"), "ProbeApp requests notification access (documented API)");
    Check(appSrc.Contains("COUNT_ONLY_NO_TEXT_READ"), "ProbeApp marks the count-only text-handling site");
    Check(appSrc.Contains("UserNotificationListener"), "ProbeApp uses UserNotificationListener");

    // The manifest declares the listener capability and NO network capability.
    var man = File.ReadAllText(manifest);
    var manCode = StripXmlComments(man);
    Check(man.Contains("userNotificationListener"), "manifest declares userNotificationListener capability");
    Check(!manCode.Contains("internetClient"), "manifest declares NO internet capability");
    Check(!manCode.ToLowerInvariant().Contains("privatenetwork"), "manifest declares no private-network capability");
}

Console.WriteLine();
Console.WriteLine(failures == 0 ? "ALL PROBE-CORE CHECKS PASSED" : $"{failures} CHECK(S) FAILED");
return failures == 0 ? 0 : 1;

static string StripCsComments(string s)
{
    s = System.Text.RegularExpressions.Regex.Replace(s, @"/\*.*?\*/", " ", System.Text.RegularExpressions.RegexOptions.Singleline);
    s = System.Text.RegularExpressions.Regex.Replace(s, @"//[^\n]*", " ");
    return s;
}

static string StripXmlComments(string s)
    => System.Text.RegularExpressions.Regex.Replace(s, @"<!--.*?-->", " ", System.Text.RegularExpressions.RegexOptions.Singleline);

static string? FindProbeRoot(string start)
{
    var d = new DirectoryInfo(start);
    while (d != null)
    {
        if (Directory.Exists(Path.Combine(d.FullName, "ProbeApp")) &&
            Directory.Exists(Path.Combine(d.FullName, "ProbeCore")))
            return d.FullName;
        d = d.Parent;
    }
    return null;
}
