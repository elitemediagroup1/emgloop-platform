using System.Windows.Forms;
using Windows.UI.Notifications.Management;
using Loop.CoverageProbe.Core;

namespace Loop.CoverageProbe.App;

/// The whole UI. It shows access status, three running counters, and the local output
/// path. It never displays any notification content -- there is none to display.
internal sealed class MainForm : Form
{
    private readonly NotificationProbe _probe = new();
    private readonly string _outputPath;
    private int _teams, _telegram, _other;

    private readonly Label _status = new() { AutoSize = true, Location = new(12, 12) };
    private readonly Label _counts = new() { AutoSize = true, Location = new(12, 40) };
    private readonly Label _pathLabel = new() { AutoSize = true, Location = new(12, 68), MaximumSize = new(520, 0) };
    private readonly Button _grant = new() { Text = "1. Grant notification access", Location = new(12, 100), Width = 250 };
    private readonly Button _start = new() { Text = "2. Start coverage test", Location = new(12, 135), Width = 250, Enabled = false };
    private readonly Button _stop = new() { Text = "Stop", Location = new(270, 135), Width = 120, Enabled = false };

    public MainForm()
    {
        Text = "Loop Coverage Probe (B0)";
        ClientSize = new(560, 190);

        var dir = System.IO.Path.Combine(
            System.Environment.GetFolderPath(System.Environment.SpecialFolder.LocalApplicationData),
            "LoopCoverageProbe");
        System.IO.Directory.CreateDirectory(dir);
        _outputPath = System.IO.Path.Combine(dir, "coverage.jsonl");
        _pathLabel.Text = "Records written to: " + _outputPath;

        Controls.AddRange(new Control[] { _status, _counts, _pathLabel, _grant, _start, _stop });

        _status.Text = "Access: " + _probe.AccessStatus;
        _start.Enabled = _probe.AccessStatus == UserNotificationListenerAccessStatus.Allowed;
        UpdateCounts();

        _probe.RecordObserved += OnRecord;
        _probe.OtherObserved += OnOther;

        _grant.Click += async (_, _) =>
        {
            var s = await _probe.RequestAccessAsync();
            _status.Text = "Access: " + s;
            _start.Enabled = s == UserNotificationListenerAccessStatus.Allowed;
        };
        _start.Click += async (_, _) =>
        {
            await _probe.StartAsync();
            _grant.Enabled = false; _start.Enabled = false; _stop.Enabled = true;
            _status.Text = "Listening. Use Teams and Telegram normally.";
        };
        _stop.Click += (_, _) =>
        {
            _probe.Stop();
            _stop.Enabled = false; _start.Enabled = true; _grant.Enabled = true;
            _status.Text = "Stopped.";
        };
    }

    private void OnRecord(ProbeRecord r)
    {
        try { System.IO.File.AppendAllText(_outputPath, RecordSerializer.ToJsonLine(r) + System.Environment.NewLine); }
        catch { /* never throw from the notification callback */ }
        if (r.Kind == AppKind.Teams) System.Threading.Interlocked.Increment(ref _teams);
        else if (r.Kind == AppKind.Telegram) System.Threading.Interlocked.Increment(ref _telegram);
        BeginInvoke(UpdateCounts);
    }

    private void OnOther()
    {
        System.Threading.Interlocked.Increment(ref _other);
        BeginInvoke(UpdateCounts);
    }

    private void UpdateCounts()
        => _counts.Text = $"Teams: {_teams}     Telegram: {_telegram}     Other apps (count only): {_other}";
}
