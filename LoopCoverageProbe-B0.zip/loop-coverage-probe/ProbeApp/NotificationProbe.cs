using Windows.UI.Notifications;
using Windows.UI.Notifications.Management;
using Loop.CoverageProbe.Core;

namespace Loop.CoverageProbe.App;

/// Wraps the documented Windows notification listener
/// (Windows.UI.Notifications.Management.UserNotificationListener).
///
/// It reads ONLY, per notification:
///   - the producing app's AppUserModelId (source application identity),
///   - the notification's creation time,
///   - WHETHER the toast carried any text elements (a COUNT, never the text).
///
/// It never reads notification text, never removes or modifies a notification,
/// makes no network call, and touches no credential, cookie, token or app store.
internal sealed class NotificationProbe
{
    private readonly UserNotificationListener _listener = UserNotificationListener.Current;
    private bool _listening;

    public event System.Action<ProbeRecord>? RecordObserved;
    public event System.Action? OtherObserved;

    public System.Threading.Tasks.Task<UserNotificationListenerAccessStatus> RequestAccessAsync()
        => _listener.RequestAccessAsync().AsTask();

    public UserNotificationListenerAccessStatus AccessStatus => _listener.GetAccessStatus();

    public async System.Threading.Tasks.Task StartAsync()
    {
        if (_listening) return;
        _listening = true;
        _listener.NotificationChanged += OnChanged;
        // Sweep the notifications already present when listening starts.
        var current = await _listener.GetNotificationsAsync(NotificationKinds.Toast);
        foreach (var n in current) Process(n);
    }

    public void Stop()
    {
        if (!_listening) return;
        _listening = false;
        _listener.NotificationChanged -= OnChanged;
    }

    private void OnChanged(UserNotificationListener sender, UserNotificationChangedEventArgs args)
    {
        if (args.ChangeKind != UserNotificationChangedKind.Added) return; // ignore removals; never act on them
        UserNotification? n = null;
        try { n = _listener.GetNotification(args.UserNotificationId); } catch { /* gone already */ }
        if (n != null) Process(n);
    }

    private void Process(UserNotification n)
    {
        // Item 1: source application identity (AUMID). App-level, never a person.
        string appId = n.AppInfo?.AppUserModelId ?? "";
        AppKind kind = SourceClassifier.Classify(appId);
        if (kind == AppKind.Other) { OtherObserved?.Invoke(); return; }

        // Item 3: WHETHER text was present. COUNT_ONLY_NO_TEXT_READ: we read the element
        // COUNT only, and never access any element's text.
        bool hadText = false;
        try
        {
            var binding = n.Notification?.Visual?.GetBinding(KnownNotificationBindings.ToastGeneric);
            if (binding != null)
            {
                var texts = binding.GetTextElements();
                hadText = texts != null && texts.Count > 0;
            }
        }
        catch { /* leave hadText false */ }

        RecordObserved?.Invoke(new ProbeRecord(kind, appId, n.CreationTime, hadText));
    }
}
