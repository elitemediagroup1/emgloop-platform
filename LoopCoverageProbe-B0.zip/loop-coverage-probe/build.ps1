# Loop Coverage Probe (B0) — build, package (MSIX) and sign for local sideload testing.
# Run on WINDOWS in an elevated PowerShell (needed to trust the self-signed dev cert).
# Requires: .NET 10 SDK, and the Windows 10/11 SDK (for makeappx.exe / signtool.exe).
# This script was authored on Linux and could NOT be executed here — review before running.
$ErrorActionPreference = "Stop"
$root = $PSScriptRoot
$pub  = Join-Path $root "publish"
$msix = Join-Path $root "LoopCoverageProbe.msix"

# 1. Build the WinForms app (Windows-only TFM). No network access is compiled in.
dotnet publish (Join-Path $root "ProbeApp\ProbeApp.csproj") -c Release -r win-x64 --self-contained false -p:Platform=x64 -o $pub

# 2. Lay the MSIX payload out: the manifest and logos beside the published binaries.
Copy-Item (Join-Path $root "Packaging\Package.appxmanifest") (Join-Path $pub "AppxManifest.xml") -Force
Copy-Item (Join-Path $root "Packaging\Images") (Join-Path $pub "Images") -Recurse -Force

# 3. Pack. (makeappx.exe ships with the Windows SDK; ensure it is on PATH.)
makeappx.exe pack /d $pub /p $msix /o

# 4. Create a self-signed DEV certificate whose subject EXACTLY matches the manifest Publisher,
#    trust it locally, and sign the package. This is a throwaway test cert.
$cert = New-SelfSignedCertificate -Type Custom -Subject "CN=EliteMediaGroup-Dev" `
    -KeyUsage DigitalSignature -FriendlyName "Loop Coverage Probe Dev" `
    -CertStoreLocation "Cert:\CurrentUser\My" `
    -TextExtension @("2.5.29.37={text}1.3.6.1.5.5.7.3.3", "2.5.29.19={text}")
Export-Certificate -Cert $cert -FilePath (Join-Path $root "probe-dev.cer") | Out-Null
Import-Certificate -FilePath (Join-Path $root "probe-dev.cer") -CertStoreLocation "Cert:\LocalMachine\TrustedPeople" | Out-Null
signtool.exe sign /fd SHA256 /sha1 $cert.Thumbprint $msix

Write-Host ""
Write-Host "Built and signed: $msix"
Write-Host "Install with:  Add-AppxPackage `"$msix`""
Write-Host "Dev cert thumbprint (remove during cleanup): $($cert.Thumbprint)"
