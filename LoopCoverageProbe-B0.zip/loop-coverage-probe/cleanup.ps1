# Loop Coverage Probe (B0) — complete removal. Run on WINDOWS (elevated).
$ErrorActionPreference = "SilentlyContinue"
# 1. Uninstall the app.
Get-AppxPackage -Name "EliteMediaGroup.LoopCoverageProbe" | Remove-AppxPackage
# 2. Delete the only data it wrote.
Remove-Item -Recurse -Force (Join-Path $env:LOCALAPPDATA "LoopCoverageProbe")
# 3. Remove the throwaway dev signing cert from the machine trust store.
Get-ChildItem Cert:\LocalMachine\TrustedPeople | Where-Object { $_.Subject -eq "CN=EliteMediaGroup-Dev" } | Remove-Item
Get-ChildItem Cert:\CurrentUser\My        | Where-Object { $_.Subject -eq "CN=EliteMediaGroup-Dev" } | Remove-Item
Write-Host "Removed the app, its local data, and the dev certificate."
Write-Host "Finally: Settings > Privacy & security > Notifications — revoke access for the probe (or leave; it is gone)."
