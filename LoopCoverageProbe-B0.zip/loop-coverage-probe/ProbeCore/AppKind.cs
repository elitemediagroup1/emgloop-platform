namespace Loop.CoverageProbe.Core;

/// The only classifications the probe records for a notification's SOURCE APPLICATION.
/// None of these values identifies a person, a sender, a conversation or any message.
public enum AppKind
{
    Teams,
    Telegram,
    Other,
}
