namespace Loop.CoverageProbe.Core;

/// The ENTIRE shape of what the probe may persist about a single notification.
///
/// It is structurally impossible for this record to carry a notification title,
/// preview, sender name, conversation name or message body: no such field exists,
/// and ProbeRecordShapeTests asserts the public property set stays exactly these four.
///
///   Kind            -- Teams / Telegram / Other (item 4: the coverage result)
///   AppIdentity     -- the producing app's AUMID (item 1: source application identity)
///   TimestampUtc    -- when the notification was created (item 2)
///   HadTextElements -- WHETHER the toast carried any text, never the text itself (item 3)
public sealed record ProbeRecord(
    AppKind Kind,
    string AppIdentity,
    System.DateTimeOffset TimestampUtc,
    bool HadTextElements);
