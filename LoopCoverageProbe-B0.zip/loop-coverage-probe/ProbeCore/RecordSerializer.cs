using System.Text;
using System.Text.Json;

namespace Loop.CoverageProbe.Core;

/// Serializes a ProbeRecord to a single JSON line using an EXPLICIT key allowlist.
/// Exactly four keys are ever written; there is no reflection-based/object serializer
/// that could pick up a future content field.
public static class RecordSerializer
{
    /// The complete set of keys this serializer can ever emit. Tests pin it.
    public static readonly string[] AllowedKeys = { "kind", "appId", "ts", "hadText" };

    public static string ToJsonLine(ProbeRecord r)
    {
        using var ms = new MemoryStream();
        using (var w = new Utf8JsonWriter(ms))
        {
            w.WriteStartObject();
            w.WriteString("kind", r.Kind.ToString());
            w.WriteString("appId", r.AppIdentity);
            w.WriteString("ts", r.TimestampUtc.ToUniversalTime().ToString("o"));
            w.WriteBoolean("hadText", r.HadTextElements);
            w.WriteEndObject();
        }
        return Encoding.UTF8.GetString(ms.ToArray());
    }
}
