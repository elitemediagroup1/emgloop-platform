namespace Loop.CoverageProbe.Core;

/// Pure, content-free classification of a notification's SOURCE APPLICATION.
///
/// The ONLY input is the producing app's AppUserModelId (AUMID) -- an application
/// identity string set by the app itself. It is never a person, a sender, a chat
/// name, a preview or message text. No notification content is read to classify.
public static class SourceClassifier
{
    public static AppKind Classify(string? appUserModelId)
    {
        if (string.IsNullOrWhiteSpace(appUserModelId)) return AppKind.Other;
        var id = appUserModelId.Trim();

        // Telegram Desktop (Win32) sets its AUMID to "Telegram.TelegramDesktop";
        // the Microsoft Store build's package family is "TelegramMessengerLLP.TelegramDesktop_...".
        // Match the stable "Telegram" token, case-insensitively.
        if (id.Contains("Telegram", System.StringComparison.OrdinalIgnoreCase))
            return AppKind.Telegram;

        // New Teams ships as MSIX with package family name "MSTeams_8wekyb3d8bbwe"
        // (AUMID "MSTeams_8wekyb3d8bbwe!MSTeams"); classic Teams used
        // "com.squirrel.Teams.Teams". Match "MSTeams" or "Teams".
        if (id.Contains("MSTeams", System.StringComparison.OrdinalIgnoreCase) ||
            id.Contains("Teams", System.StringComparison.OrdinalIgnoreCase))
            return AppKind.Teams;

        return AppKind.Other;
    }
}
